"""Predict paired-primer products in reference FASTA files; coordinates are 1-based inclusive.

Python 3, standard library only. Searches are exhaustive for the stated ungapped
criteria: exact; <=3 substitutions at any position; and a sensitivity
screen allowing <=6 substitutions with the terminal 8 nt exact. Product size is
50-1000 bp, including primers. Both F/R orientations and F/F and R/R products
are examined. This is a sequence screen, not a thermodynamic PCR simulation.
"""
from pathlib import Path
import argparse, csv, gzip, json, hashlib, sys
from collections import defaultdict, Counter

PAIRS = {}
COMP = str.maketrans('ACGTN', 'TGCAN')
def rc(s): return s.translate(COMP)[::-1]
def op(p): return gzip.open(p, 'rt') if str(p).endswith('.gz') else open(p)
def fasta(path):
    with op(path) as f:
        name, chunks = None, []
        for line in f:
            if line.startswith('>'):
                if name is not None: yield name, ''.join(chunks).upper()
                name, chunks = line[1:].split()[0], []
            else: chunks.append(line.strip())
        if name is not None: yield name, ''.join(chunks).upper()
def attrs(s): return dict(x.split('=', 1) for x in s.strip().split(';') if '=' in x)
def write_tsv(path, rows, fields):
    with open(path, 'w') as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter='\t', lineterminator='\n')
        w.writeheader(); w.writerows(rows)
def annotation(path):
    tx, exons, genes = {}, defaultdict(list), defaultdict(list)
    with op(path) as f:
        for line in f:
            if line.startswith('#'): continue
            chrom, _, typ, lo, hi, _, strand, _, info = line.rstrip().split('\t')
            a = attrs(info); lo, hi = int(lo)-1, int(hi)
            if typ == 'gene': genes[chrom].append((lo, hi, strand, a['ID']))
            elif typ == 'mRNA': tx[a['ID']] = (chrom, strand, a['Parent'])
            elif typ == 'exon':
                for parent in a['Parent'].split(','): exons[parent].append((lo, hi))
    return tx, exons, genes
def transcript_fasta(path, genome, tx, exons):
    with gzip.open(path, 'wt') as out:
        for tid, (chrom, strand, _) in tx.items():
            s = ''.join(genome[chrom][a:b] for a,b in sorted(exons[tid]))
            if strand == '-': s = rc(s)
            out.write('>'+tid+'\n'+s+'\n')
def sites(seq, primer):
    n=len(primer);out=[];seen=set()
    # Four disjoint seeds guarantee at least one exact block for <=3 substitutions.
    # The terminal block is also contained in the terminal 8-nt sensitivity seed.
    blocks=[(n*i//4,n*(i+1)//4) for i in range(4)]
    for strand in ['+','-']:
        for lo,hi in blocks:
            seed=primer[lo:hi] if strand=='+' else rc(primer[lo:hi])
            pos=seq.find(seed)
            while pos>=0:
                start=pos-lo if strand=='+' else pos-(n-hi)
                key=(start,strand)
                if 0<=start and start+n<=len(seq) and key not in seen:
                    seen.add(key)
                    template=seq[start:start+n]
                    if strand=='-':template=rc(template)
                    tail8=template[-8:]==primer[-8:]
                    limit=6 if tail8 else 3
                    mm=[]
                    for i,(a,b) in enumerate(zip(primer,template)):
                        if a!=b:
                            mm.append(i+1)
                            if len(mm)>limit:break
                    if len(mm)<=limit:
                        out.append(dict(start=start,end=start+n,strand=strand,mismatches=len(mm),
                            mm_positions=','.join(map(str,mm)),template=template,tail8=tail8))
                pos=seq.find(seed,pos+1)
    return out
def accepted(s, criterion):
    if criterion == 'exact': return s['mismatches'] == 0
    if criterion == 'screen': return s['mismatches'] <= 3
    return s['mismatches'] <= 6 and s['tail8']
def search(label, records, outdir, tx, genes):
    products, bindings, counts = [], [], Counter()
    for sid, seq in records:
        counts['sequences'] += 1; counts['bases'] += len(seq)
        gene = tx[sid][2] if sid in tx else sid.split('.mRNA')[0]
        for assay, (target, fwd, rev) in PAIRS.items():
            ends = {'F': sites(seq, fwd), 'R': sites(seq, rev)}
            for end, ss in ends.items():
                for s in ss:
                    bindings.append(dict(database=label,assay=assay,primer=end,sequence_id=sid,
                        gene=gene if label!='genome' else '',start=s['start']+1,end=s['end'],
                        strand=s['strand'],mismatches=s['mismatches'],mm_positions=s['mm_positions'],
                        aligned_template=s['template'],terminal8_exact=s['tail8']))
            for criterion in ['exact','screen','sensitivity']:
                for left, right in [('F','R'),('R','F'),('F','F'),('R','R')]:
                    for a in ends[left]:
                        if a['strand']!='+' or not accepted(a,criterion): continue
                        for b in ends[right]:
                            if b['strand']!='-' or not accepted(b,criterion) or b['start']<a['end']: continue
                            size = b['end']-a['start']
                            if not 50 <= size <= 1000: continue
                            if label == 'genome':
                                overlaps = sorted(g for lo,hi,st,g in genes[sid] if lo<b['end'] and hi>a['start'])
                            else: overlaps=[gene]
                            products.append(dict(database=label,criterion=criterion,assay=assay,
                                intended_gene=target,sequence_id=sid,genes=';'.join(overlaps),
                                primer_configuration=left+'+/'+right+'-',start=a['start']+1,
                                end=b['end'],length_bp=size,left_mismatches=a['mismatches'],
                                right_mismatches=b['mismatches'],left_mm_positions=a['mm_positions'],
                                right_mm_positions=b['mm_positions'],
                                intended_gene_in_annotation=target in overlaps,
                                product_sequence=seq[a['start']:b['end']]))
        if counts['sequences'] % 25000 == 0:
            print(label, counts['sequences'], 'records',flush=True)
    sf=['database','assay','primer','sequence_id','gene','start','end','strand','mismatches','mm_positions','aligned_template','terminal8_exact']
    pf=['database','criterion','assay','intended_gene','sequence_id','genes','primer_configuration','start','end','length_bp','left_mismatches','right_mismatches','left_mm_positions','right_mm_positions','intended_gene_in_annotation','product_sequence']
    write_tsv(outdir/(label+'_binding_sites.tsv'),bindings,sf)
    write_tsv(outdir/(label+'_products.tsv'),products,pf)
    summaries=[]
    for assay,(target,_,_) in PAIRS.items():
        for criterion in ['exact','screen','sensitivity']:
            pp=[p for p in products if p['assay']==assay and p['criterion']==criterion]
            summaries.append(dict(database=label,criterion=criterion,assay=assay,intended_gene=target,
                product_records=len(pp),sequence_ids=';'.join(sorted({p['sequence_id'] for p in pp})),
                gene_ids=';'.join(sorted({g for p in pp for g in p['genes'].split(';') if g})),
                product_lengths=';'.join(map(str,sorted({p['length_bp'] for p in pp}))),
                non_target_product_records=sum(not p['intended_gene_in_annotation'] for p in pp)))
    print(label,dict(counts),'product records',len(products),flush=True)
    return summaries,dict(counts)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--design',type=Path)
    ap.add_argument('--pairs',type=Path,required=True)
    a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    global PAIRS
    PAIRS=json.loads(a.pairs.read_text())
    print('Loading reference',flush=True)
    genome=dict(fasta(a.data/'Cucumber.CLv4.fa.gz'))
    tx,exons,genes=annotation(a.data/'Cucumber.CLv4.gff3.gz')
    rna=a.data/'Cucumber.CLv4.spliced_mRNA.fa.gz'
    if not rna.exists():transcript_fasta(rna,genome,tx,exons)
    summaries,db=[],{}
    datasets=[('genome',genome.items()),('mRNA',fasta(rna)),('CDS',fasta(a.data/'Cucumber.CLv4.cds.fa.gz'))]
    if a.design:datasets.append(('design',fasta(a.design)))
    for label,records in datasets:
        ss,nn=search(label,records,a.output,tx,genes);summaries.extend(ss);db[label]=nn
    write_tsv(a.output/'paired_primer_summary.tsv',summaries,list(summaries[0]))
    (a.output/'analysis_parameters.json').write_text(json.dumps(dict(python=sys.version,databases=db,
        primer_pairs=PAIRS,product_min_bp=50,product_max_bp=1000,gaps_allowed=False,
        criteria={'exact':'Full-length exact match','screen':'Full-length <=3 substitutions at any primer position',
                  'sensitivity':'Full-length <=6 substitutions, terminal 8 nt exact'},
        primer_configurations=['F+/R-','R+/F-','F+/F-','R+/R-']),indent=2))
if __name__=='__main__':main()
