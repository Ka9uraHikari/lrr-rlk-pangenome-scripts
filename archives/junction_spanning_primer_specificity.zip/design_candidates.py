from pathlib import Path
import sys,json,csv
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'python_lib'))
import primer3

models=json.loads((W/'data/target_models.json').read_text())
TARGETS={'CR133':'CsaV4_7G002666.mRNA2','CR132':'CsaV4_7G002654.mRNA2','SC013':'CsaV4_2G003347.mRNA2'}
settings={
 'PRIMER_TASK':'generic','PRIMER_PICK_LEFT_PRIMER':1,'PRIMER_PICK_RIGHT_PRIMER':1,
 'PRIMER_PICK_INTERNAL_OLIGO':0,'PRIMER_NUM_RETURN':30,
 'PRIMER_MIN_SIZE':20,'PRIMER_OPT_SIZE':21,'PRIMER_MAX_SIZE':24,
 'PRIMER_MIN_TM':58.0,'PRIMER_OPT_TM':60.0,'PRIMER_MAX_TM':62.0,
 'PRIMER_PAIR_MAX_DIFF_TM':1.0,'PRIMER_MIN_GC':40.0,'PRIMER_MAX_GC':60.0,
 'PRIMER_MAX_POLY_X':4,'PRIMER_MAX_NS_ACCEPTED':0,'PRIMER_MAX_END_GC':3,
 'PRIMER_THERMODYNAMIC_OLIGO_ALIGNMENT':1,'PRIMER_THERMODYNAMIC_TEMPLATE_ALIGNMENT':0,
 'PRIMER_MAX_SELF_ANY_TH':40.0,'PRIMER_MAX_SELF_END_TH':30.0,
 'PRIMER_PAIR_MAX_COMPL_ANY_TH':40.0,'PRIMER_PAIR_MAX_COMPL_END_TH':30.0,
 'PRIMER_MAX_HAIRPIN_TH':40.0,'PRIMER_PRODUCT_SIZE_RANGE':[[80,150]],
 'PRIMER_MIN_3_PRIME_OVERLAP_OF_JUNCTION':8,'PRIMER_MIN_5_PRIME_OVERLAP_OF_JUNCTION':8,
 'PRIMER_SALT_MONOVALENT':50.0,'PRIMER_SALT_DIVALENT':1.5,'PRIMER_DNTP_CONC':0.6,
 'PRIMER_DNA_CONC':50.0,'PRIMER_TM_FORMULA':1,'PRIMER_SALT_CORRECTIONS':1,
 'PRIMER_EXPLAIN_FLAG':1}
rows=[];raw={};templates={};n=0
for assay,tid in TARGETS.items():
 seq=models['mRNA_sequences'][tid];cds=models['CDS_sequences'][tid]
 cstart=seq.find(cds);assert cstart>=0,(tid,'CDS not contained in spliced mRNA')
 exons=sorted(models['exons'][tid],reverse=models['transcripts'][tid]['strand']=='-')
 sizes=[hi-lo+1 for lo,hi in exons];boundaries=[];b=0
 for size in sizes[:-1]:b+=size;boundaries.append(b)
 templates[tid]={'sequence':seq,'cds_start_0based':cstart,'cds_length':len(cds),'junctions':boundaries,'exons_in_transcription_order':exons}
 for ji,j in enumerate(boundaries,1):
  if not cstart+8<j<cstart+len(cds)-8:continue
  args={'SEQUENCE_ID':tid,'SEQUENCE_TEMPLATE':seq,'SEQUENCE_INCLUDED_REGION':[cstart,len(cds)],'SEQUENCE_OVERLAP_JUNCTION_LIST':[j-1]}
  out=primer3.bindings.design_primers(args,settings)
  raw[assay+'_junction'+str(ji)]=out
  kept=[]
  for k in range(out['PRIMER_PAIR_NUM_RETURNED']):
   f=out[f'PRIMER_LEFT_{k}_SEQUENCE'];r=out[f'PRIMER_RIGHT_{k}_SEQUENCE']
   fp,fl=out[f'PRIMER_LEFT_{k}'];rp,rl=out[f'PRIMER_RIGHT_{k}'];rs=rp-rl+1
   # Independently verify the actual junction split rather than relying on an index convention.
   jf=fp<j<fp+fl and min(j-fp,fp+fl-j)>=8
   jr=rs<j<rp+1 and min(j-rs,rp+1-j)>=8
   if not (jf or jr):continue
   if any(abs(fp-a)<4 and abs(rp-b)<4 for a,b in kept):continue
   kept.append((fp,rp));n+=1
   pair_id=assay+f'_J{ji:02}_P{k+1:02}'
   row=dict(pair_id=pair_id,assay=assay,gene=tid.split('.mRNA')[0],transcript=tid,junction=ji,
    junction_mRNA_boundary=j,forward=f,reverse=r,forward_start=fp+1,forward_end=fp+fl,
    reverse_start=rs+1,reverse_end=rp+1,product_bp=rp-fp+1,product_sequence=seq[fp:rp+1],
    forward_Tm=out[f'PRIMER_LEFT_{k}_TM'],reverse_Tm=out[f'PRIMER_RIGHT_{k}_TM'],
    forward_GC=out[f'PRIMER_LEFT_{k}_GC_PERCENT'],reverse_GC=out[f'PRIMER_RIGHT_{k}_GC_PERCENT'],
    forward_hairpin_Tm=out.get(f'PRIMER_LEFT_{k}_HAIRPIN_TH',0),reverse_hairpin_Tm=out.get(f'PRIMER_RIGHT_{k}_HAIRPIN_TH',0),
    pair_any_Tm=out[f'PRIMER_PAIR_{k}_COMPL_ANY_TH'],pair_end_Tm=out[f'PRIMER_PAIR_{k}_COMPL_END_TH'],
    junction_primer='F' if jf else 'R',penalty=out[f'PRIMER_PAIR_{k}_PENALTY'])
   rows.append(row)
   if len(kept)>=(12 if assay=='SC013' else 4):break
  print(assay,'junction',ji,'returned',out['PRIMER_PAIR_NUM_RETURNED'],'retained',len(kept),flush=True)
rows=sorted(rows,key=lambda x:(x['assay'],x['penalty']))
(W/'data/primer3_settings.json').write_text(json.dumps(dict(primer3_py=primer3.__version__,settings=settings,templates=templates),indent=2))
(W/'results/primer3_raw.json').write_text(json.dumps(raw,indent=2))
(W/'results/candidates.json').write_text(json.dumps(rows,indent=2))
with open(W/'results/candidates.tsv','w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
with open(W/'data/candidate_primers.fa','w') as f:
 for r in rows:
  for end,col in [('F','forward'),('R','reverse')]:f.write('>'+r['pair_id']+'-'+end+'\n'+r[col]+'\n')
with open(W/'data/design_templates.fa','w') as f:
 for tid,d in templates.items():f.write('>'+tid+'\n'+d['sequence']+'\n')
print('Primer3-py',primer3.__version__,'retained pairs',len(rows))
